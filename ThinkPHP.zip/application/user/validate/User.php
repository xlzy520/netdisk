<?php

namespace app\user\validate;
use think\Validate;
class User extends Validate{
    protected $rule = [
        'Username' => 'require|min:4',
        'Password' => 'require|min:6:'
    ];
    protected $message = [
        'Username.require' => '用户名不能为空',
        'Username.min' => '用户名长度不能少于4位 ',
        'Password.require' => '密码不能为空',
        'Password.min' => '密码长度不能少于6位'
    ];
    protected $scene = [
        'register' => ['Username','Password']
    ];
}