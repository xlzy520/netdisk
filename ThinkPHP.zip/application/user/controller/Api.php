<?php
namespace app\user\controller;
use think\Controller;
use think\Db;
use app\user\controller\JWT;
header('Access-Control-Allow-Origin: *');
//header('Access-Control-Allow-Credentials:true');//保持跨域后session一致
//header('Content-type: application/json; charset=utf-8');

class Api extends Controller{
     function __construct(){
        if(request()->method()!='POST'){
            header('HTTP/1.1 404 Not Found');
            exit();
        }        
     }       
    /**
     * code： 
     * 状态码 1 返回成功 
     * 0 返回失败 此时，请关注msg错误信息
     */
    function user_login(){
        // $captcha = new \think\captcha\Captcha();
        // if(!$captcha->check(input('post.captcha'))){
        //     $this->error('验证码有误','user/login');
        // }
        $data = [
            'Username' => input('post.username'),
            'Password' => input('post.password')!=''? md5(input('post.password')):input('post.password'),
        ];
        $find_userName=DB::name('user')->where(['Username' => input('post.username')])->select();
        $user_info=DB::name('user')->where($data)->select();
        $login_result=[];
        //1、用户名不存在2、用户名/密码有误3、登录成功
        if($user_info){
            $user_info[0]['token']=$this->setJwtToken();
            array_splice($user_info[0],1,1);
            //session('user', $user_info);
            $login_result['code']=1;
            $login_result['msg']='登录成功';
            $login_result['userInfo']=$user_info[0];
            echo json_encode($login_result);
            return;            
        }else if($find_userName){
            $login_result['code']=0;
            $login_result['msg']='用户名/密码有误！！！';
            echo json_encode($login_result);
            return;     
        }else{
            $login_result['code']=0;
            $login_result['msg']='用户账号不存在！！！';
            echo json_encode($login_result);
            return;            
        }
        
    }
    function user_register(){
        $data = [
            'Username' => input('post.username'),
            'Password' => input('post.password'),
            'Sex' => input('post.sex'),
            'Major'=>input('post.major')
        ];
        $validate = new \app\user\validate\User;
        /**
         * code： 
         * 状态码 1 返回成功 
         * 0 返回失败 此时，请关注msg错误信息
         */
        $register_result=[];
        if(!$validate->scene('register')->check($data)){
            $register_result['code']=0;
            $register_result['msg']=$validate->getError();
            echo json_encode($register_result);
            return;
        }
        $data['Password']=md5(input('post.password'));
        if(Db::name('user')->where(['Username' => input('post.username')])->find()){
            $register_result['code']=0;
            $register_result['msg']='该用户名已存在！换个用户名继续哦！';
            echo json_encode($register_result);
            return;
        }else{
           if(Db::name('user')->insert($data)){
                if(session('?user')){
                   session('user',null);
                }
                $newUser=Db::name('user')->where('Id',Db::name('user')->getLastInsID())->select();
                //session('user', $newUser);
                $register_result['code']=1;
                $register_result['msg']='注册成功！';
                $register_result['userName']=$newUser[0]['Username'];
                $register_result['userId']=$newUser[0]['Id'];
                echo json_encode($register_result);
                return;
               
           }else{
                $register_result['code']=0;
                $register_result['msg']='注册失败，系统原因！';
                echo json_encode($register_result);
                return;
           }             
        }
    }
    //签发token
    public static function setJwtToken(){
        $key = "abcdefg";
        $time = time();
        $token = array(
            "iss" => "admin",//签发人
            "aud" => "admin",//受众
            'iat' => $time, //签发时间
            'nbf' => $time, //在什么时间之后该jwt才可用
            'exp' => $time + 3600, //过期时间
        );
        $jwt = JWT::encode($token, $key);
        return $jwt;
    }
    //解析token
    public static function parseJwtToken($jwt){
        try{
            if(empty($jwt)){
                return false;
            }
            $key = "abcdefg";            
            $decoded = JWT::decode($jwt, $key,array('HS256'));
            return true; 
        }   catch (\Exception $e) {
            return false;
        }
        //HS256方式，这里要和签发的时候对应
        // $arr = (array)$decoded;
        // if(time() >= $arr['exp']-60){
        //     return false;
        // }else{
        //     return true;
        // }
    }    
}