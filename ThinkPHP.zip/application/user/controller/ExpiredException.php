<?php
namespace app\User\controller;

class ExpiredException extends \UnexpectedValueException
{

}
