<?php
namespace app\User\controller;

class BeforeValidException extends \UnexpectedValueException
{

}
