<?php
namespace app\User\controller;

class SignatureInvalidException extends \UnexpectedValueException
{

}
