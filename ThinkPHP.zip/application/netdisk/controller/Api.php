<?php
namespace app\Netdisk\controller;
use think\Controller;
use think\Db;
use app\user\controller\Api as userApi;

header('Access-Control-Allow-Origin: *');

class Api extends Controller{
    function __construct()
    {
        if(request()->method()!='POST'){
            header('HTTP/1.1 404 Not Found');
            exit();
        }
        if(!preg_match('/share_view/i',request()->path())){
            // dump(input('post.token'));
            if(input('post.token')==null || !userApi::parseJwtToken(input('post.token'))){
                header('HTTP/1.1 401 unauthorized');
                exit();            
            }            
        }
    }   
    function get_user_file(){
      $folder_id=input('post.folder_id/d')==null?0:input('post.folder_id/d');
      $user_id=input('post.userId/d');
      $folderSql=[
          "path" =>$user_id.'-'.$folder_id
      ];
      $fileSql=[
         'User_id'=>$user_id,
         'Folder_id'=>$folder_id
      ];
      $getUserData=[
          'folder' =>[],
          'file' => []
      ];
      $getUserData['folder']=Db::name('folder')->where($folderSql)->select();      
      $getUserData['file']=Db::name('file')->where($fileSql)->select();
      $getUserShare=Db::name('share')->where(['User_id'=>$user_id])->select();
      if(count($getUserData['file']) != 0 || count($getUserData['folder']) != 0 ){
          foreach($getUserData as $index => $item){
              if($index=='folder'){
                foreach ($getUserData['folder'] as $key1 => $value2){
                   $getUserData['folder'][$key1]['Create_time']=$this->date_formate($getUserData['folder'][$key1]['Create_time']);
                }                  
              }else{
                foreach ($getUserData['file'] as $key => $value){
                        $getUserData['file'][$key]['File_ext']=$this->parse_file_ext($getUserData['file'][$key]['File_ext']); 
                        $getUserData['file'][$key]['File_size']=$this->format_file_size($getUserData['file'][$key]['File_size']);
                        $getUserData['file'][$key]['Upload_time']=$this->date_formate($getUserData['file'][$key]['Upload_time']);
                        $getUserData['file'][$key]['share_type']='private';
                        $getUserData['file'][$key]['expiry_date']=0;
                        $getUserData['file'][$key]['key']=null;
                        $getUserData['file'][$key]['share_url']=null;
                        $getUserData['file'][$key]['share_status']=false;                   
                       //判断文件是否有分享链接
                       foreach ($getUserShare as $k => $v) {
                           if($v['File_id']==$getUserData['file'][$key]['Id']){
                                $getUserData['file'][$key]['share_type']=$getUserShare[$k]['Share_type'];
                                $getUserData['file'][$key]['expiry_date']=$getUserShare[$k]['Expiry_date'];
                                $getUserData['file'][$key]['key']=$getUserShare[$k]['key'];
                                $getUserData['file'][$key]['share_url']=$getUserShare[$k]['Share_url'];
                                $getUserData['file'][$key]['share_status']=true;
                                break;
                           }
                       }
                }                  
              }
          }
          $userFile_result=[
              'folder_id' => $folder_id,
              'fileData' => $getUserData,
          ];
      }else{
          $userFile_result=[
              'folder_id' => $folder_id,
              'fileData' => $getUserData,
          ];          
      }
      echo json_encode($userFile_result);
      return;
    }
    function user_quit(){
        session('user',null);
        $this->redirect('user/user/login');
    }
    function file_upload(){
        $files = request()->file('upload_file');
        $uploads_result=[
            'success'=>[],
            'error'=>[]
        ];
        foreach($files as $key => $value){
            if ($value) {
                $upload_file_msg = $value->getInfo();//获取选择文件的信息
                $file_data[$key]['File_name'] = $upload_file_msg['name'];//获取文件的原始文件名
                $file_data[$key]['File_size'] = $this->format_file_size($upload_file_msg['size']);
                $file_info = $value->validate(config('upload_validate'))->move(ROOT_PATH.'public/uploads');//执行上传操作
                if($file_info){
                    $file_data[$key]['Folder_id'] = input('post.folder_id/d');
                    $file_data[$key]['User_id'] = input('post.userId/d');
                    $file_data[$key]['Upload_time'] = (string)time();
                    $file_data[$key]['File_ext']=$this->parse_file_ext($file_info->getExtension());                   
                    $file_data[$key]['File_save_name'] = $file_info->getSaveName();
                    Db::name('file')->insert($file_data[$key]);
                    $file_data[$key]['Upload_time']=$this->date_formate($file_data[$key]['Upload_time']);
                    array_push($uploads_result['success'],$file_data[$key]);
                }else{
                    $file_data[$key]['error_msg']=$value->getError();
                    array_push($uploads_result['error'],$file_data[$key]);
                } 
            }
        }
        echo json_encode($uploads_result);
        return;
    }
    function file_delete(){
        $user_id=input('post.userId/d');
        $needDeleteFile=[
            'User_id' => $user_id,
            'id' => input('file_id')
        ];
        if(Db::name('file')->where($needDeleteFile)->delete()){
            $file_delete_result['code']=1;
            $file_delete_result['msg']="删除文件成功！";
       } else{
            $file_delete_result['code']=0;
            $file_delete_result['msg']="删除文件失败！";
       }       
        echo json_encode($file_delete_result);
        return;
    }
    function folder_create(){
        $folder_data=[
            "Folder" => input('post.new_folder_name'),
            "Father_id" => input('post.folder_id/d'),
            "Path" => input('post.userId/d').'-'.input('post.folder_id/d'),
            "Create_time" => time()
        ];
        if(Db::name('folder')->insert($folder_data)){
            $new_folder_id = Db::name('folder')->getLastInsID();
            $new_folder_info=Db::name('folder')->where("Id",$new_folder_id)->select();
            $folder_create_result['code']=1;
            $folder_create_result['new_folder_info']=$new_folder_info[0];
            $folder_create_result['msg']="文件夹创建成功！";
        } else{
            $folder_create_result['code']=0;
            $folder_create_result['msg']="文件夹创建失败！";
        }       
        echo json_encode($folder_create_result);
        return;
    }
    function folder_delete(){
        $userId=input('post.userId/d');
        $folder_id=input('post.folder_id/d');
        $needDeleteFolder=[
            'Id' => $folder_id,
        ];
        $needDeleteFile=[
            'Folder_id' => $folder_id,
        ];        
        $existsSubFolder=Db::name('folder')->where(["path"=>$userId."-".$folder_id])->select();
        $folder_delete_result=[];
        if(count($existsSubFolder)!=0){
            $folder_delete_result['code']=0;
            $folder_delete_result['msg']="删除文件夹失败，含有子文件夹，无法删除！";
        }else{
            //删除文件夹下的文件
           $existsSubFile=Db::name('file')->where($needDeleteFile)->select();
           if(count($existsSubFile)!=0){
                Db::name('file')->where($needDeleteFile)->delete();
           }
           if(Db::name('folder')->where($needDeleteFolder)->delete()){
                $folder_delete_result['code']=1;
                $folder_delete_result['msg']="删除文件夹成功！";
            } 
        }
        echo json_encode($folder_delete_result);
        return;        
    }
    function edit_folder(){
        $folder_Id=input('post.folder_Id/d');
        $new_folder_name=input('post.new_folder_name');
        if(Db::name('folder')->where('Id',$folder_Id)->setField('Folder',$new_folder_name)){
            $edit_folder_result["code"]=1;
            $edit_folder_result["msg"]="文件夹重命名更新成功";
        }else{
            $edit_folder_result["code"]=0;
            $edit_folder_result["msg"]="文件夹重命名更新失败/你并没未最修改";            
        }
        echo json_encode($edit_folder_result);
        return;        
    }
    function create_share(){
        $data=[
            'User_id'=>input('post.userId/d'),
            'File_id'=>input('post.file_id/d'),
            'Share_type' => input('post.share_type'),
            "Expiry_date"=>input('post.expiry_date/d'),
            "key"=>$this->randomKeys(),
            "Share_date"=>time(),
            "Share_url"=>$this->shorUrl(input('post.file_id/d'))
        ];
        $share_id=Db::name('share')->insertGetId($data);
        if($share_id){
            $create_share_result['code']=1;
            $create_share_result['msg']="分享成功！";
            $create_share_result['new_share_info']=$data;
        }else{
            $create_share_result['code']=0;
            $create_share_result['msg']="分享失败！";
        }
        echo json_encode($create_share_result);
        return;
    }
    function share_view(){ 
        $user_share = Db::name('share')->where('Share_url',input('post.shareUrl'))->select();;
        $share_view_result=[];
        foreach ($user_share as $key => $value){
            if($value['File_id']){
                $findFileInfo = Db::name('file')->where('Id',$value['File_id'])->find();
                $shareUserInfo = Db::name('user')->where('Id',$value['User_id'])->find();
                $needFileInfo=[
                    "File_name"=>$findFileInfo["File_name"],
                    "File_save_name"=>$findFileInfo["File_save_name"],
                    "File_ext"=>$findFileInfo["File_ext"],
                    "File_size"=>$findFileInfo["File_size"],
                    "User_name"=>$shareUserInfo["Username"],

                ];
                
                if($findFileInfo) array_push($share_view_result, array_merge($value, $needFileInfo));
            }
        }
        foreach($share_view_result as $key => $value){
            $share_view_result[$key]['File_ext']=$this->parse_file_ext($value['File_ext']);
            if($value['Share_type']=='open'){
                if($value['Expiry_date']==0){
                    $share_view_result[$key]['Share_status']=true;
                }else{
                    if(time() > strtotime('+'.$value['Expiry_date'].' days')){
                        $share_view_result[$key]['Share_status']=false;
                    }else{
                        $share_view_result[$key]['Share_status']=true;
                    } 
                }
            }elseif($value['Share_type']=='private'){
                if($value['Expiry_date']==0){
                    $share_view_result[$key]['Share_status']=true;
                }else{
                    if(time() > strtotime('+'.$value['Expiry_date'].' days')){
                        $share_view_result[$key]['Share_status']=false;
                    }else{
                        $share_view_result[$key]['Share_status']=true;
                    } 
                }
            }
            $share_view_result[$key]['File_size'] = $this->format_file_size($value['File_size']);
        }
        if(count($share_view_result)==0){
            echo json_encode($share_view_result);
        }else{
            echo json_encode($share_view_result[0]);
        }
        return;

    }
    function share_list(){
        $user_share = Db::name('share')->where('User_id',input('post.userId/d'))->select();
        $share_list_result=[];
        foreach ($user_share as $key => $value){
            if($value['File_id']){
                $findFileInfo = Db::name('file')->where('Id',$value['File_id'])->find();
                $needFileInfo=[
                    "File_name"=>$findFileInfo["File_name"],
                    "File_ext"=>$findFileInfo["File_ext"],
                    "File_size"=>$findFileInfo["File_size"]
                ];
                
                if($findFileInfo) array_push($share_list_result, array_merge($value, $needFileInfo));
            }
        }
        foreach($share_list_result as $key => $value){
            $share_list_result[$key]['File_ext']=$this->parse_file_ext($value['File_ext']);
            if($value['Share_type']=='open'){
                if($value['Expiry_date']==0){
                    $share_list_result[$key]['Share_status']=true;
                }else{
                    if(time() > strtotime('+'.$value['Expiry_date'].' days')){
                        $share_list_result[$key]['Share_status']=false;
                    }else{
                        $share_list_result[$key]['Share_status']=true;
                    } 
                }
            }elseif($value['Share_type']=='private'){
                if($value['Expiry_date']==0){
                    $share_list_result[$key]['Share_status']=true;
                }else{
                    if(time() > strtotime('+'.$value['Expiry_date'].' days')){
                        $share_list_result[$key]['Share_status']=false;
                    }else{
                        $share_list_result[$key]['Share_status']=true;
                    } 
                }
            }                       
            $share_list_result[$key]['Share_date'] = $this->date_formate($value['Share_date']);
            $share_list_result[$key]['File_size'] = $this->format_file_size($value['File_size']);
        }
        echo json_encode($share_list_result);
        return;
    }
    function share_delete(){
        if(Db::name('share')->where('Id',input('share_id/d'))->delete()){
            $share_delete_result['code']=1;
            $share_delete_result['msg']="分享删除成功！";       
        }else{
            $share_delete_result['code']=0;
            $share_delete_result['msg']="分享删除失败！";    
        }
        echo json_encode($share_delete_result);
        return;
    }
    function parse_file_ext($file_ext="none"){
        if(!file_exists('./static/icon/'.$file_ext.'.png')){
            if(preg_match('/jpg|gif|png|bmp/i',$file_ext)){
                return 'img';
            }elseif(preg_match('/zip|7z|gz/i',$file_ext)){
                return 'rar';
            }else{
               return 'none'; 
            }
        }
        return $file_ext;
    }    
    /**
     * @param $size
     * @return string
     * 文件字节转大小 K/M
     */
    function format_file_size($size){
        $units = array(' B', ' KB', ' MB', ' GB', ' TB');
        for ($i = 0; $size >= 1024 && $i < 4; $i++){
            $size /= 1024;
        }
        return round($size, 2).$units[$i];
    }
    function date_formate($deal_date){
            if(is_string($deal_date)){
                $compareTime = time()-(int)$deal_date;
            }else{
                $compareTime = time()-$deal_date;
            }
            if($compareTime < 60){
                    //四舍五入取整：round() 向下取整：floor()； 
                    $finalTime = floor($compareTime).'秒前';
            }elseif($compareTime >= 60 && $compareTime < 600){
                    $finalTime = floor($compareTime/60).'分钟前';
            }elseif($compareTime >= 600 && $compareTime < 60*60*24){
                    $finalTime = floor($compareTime/3600).'小时前';
            }else{
                    $finalTime = date('Y-m-d H:i:s',$deal_date);
            }
            return $finalTime;
    }
    /** 生成短网址 
    * @param  String/int $url 原网址 
    * @return String 
    */  
    function shorUrl($url){  
        $code = floatval(sprintf('%u', crc32($url)));  
        $surl = '';  
        while($code){  
            $mod = fmod($code, 62);  
            if($mod>9 && $mod<=35){  
                $mod = chr($mod + 55);  
            }elseif($mod>35){  
                $mod = chr($mod + 61);  
            }  
            $surl .= $mod;  
            $code = floor($code/62);  
        }  
        return $surl;  
    }
    /** 生成分享key 
    * @param  length
    * @return String 
    */     
    function randomKeys($length=4){   
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ';
        $key=null;
        for($i=0;$i<$length;$i++){   
            $key .= $pattern{mt_rand(0,35)};//生成php随机数   
        }   
        return $key;   
    }         
}
