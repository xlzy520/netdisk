<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:85:"D:\phpStudy\WWW\www.wangpan.com\public/../application/netdisk\view\netdisk\index.html";i:1561627881;s:83:"D:\phpStudy\WWW\www.wangpan.com\application\netdisk\view\netdisk\public\header.html";i:1561680805;s:83:"D:\phpStudy\WWW\www.wangpan.com\application\netdisk\view\netdisk\public\footer.html";i:1561681426;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>网盘中心</title>
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<link rel="stylesheet" type="text/css" href="/public/static/fontawesome-free-5.8.2-web/css/all.css" />
		<link rel="stylesheet" type="text/css" href="/public/static/sui/style.css" />
		<link rel="stylesheet" href="/public/static/sui/css/sm.min.css" />
		<link rel="stylesheet" href="/public/static/sui/css/sm-extend.min.css" />
	</head>
	<body>
		<div class="page-group">
			<div class="page page-current" id="page-index">
				<!-- 标题栏 -->
                                <header class="bar bar-nav">
        <a class="icon icon-me pull-left open-panel" ></a>
        
        <a class="button button-link button-nav pull-right open-popup" data-popup=".popup-about" style="top:9px;"><span style="font-size:1.5rem;" class="icon icon-menu"></span></a>
        <h1 class="title"><a class="external" href="./">蓝天网盘</a></h1>
</header>
                                <!-- 标题栏 -->
                                
				<div class="bar bar-header-secondary">
					<div class="row">
                                                <?php if($folder_id==0): ?><div class="col-25">&nbsp;</div>
                                                <?php else: ?>
                                                <div class="col-25">
                                                    <a href="<?php echo url('/netdisk/netdisk/index/folder_id/'.$backUrl); ?>" class="external button button-link button-nav pull-left back"><span class="icon icon-left"></span>返回</a>
                                                </div>
                                                <?php endif; ?>
						<div class="col-25">&nbsp;</div>
						<div class="col-25">
							<a class="button button-link button-nav open-popup" data-popup=".popup-add-folder">
								<i class="fa fa-plus-square fa-lg"></i> 文件夹
							</a>
						</div>
						<div class="col-25">
							<div class="button button-link button-nav">
								<form name="form1" action="<?php echo url('/netdisk/netdisk/file_upload/folder_id/'.$folder_id); ?>" method="post" enctype="multipart/form-data">
									<input style="position: absolute;width:100%;height:100%;left:0;top:10px;opacity: 0;" type="file" name="upload_file[]" multiple
									 class="file-btn" onchange="form1.submit()">
									<i class="fa fa-upload fa-lg"></i> 上传
								</form>
							</div>
						</div>
					</div>
				</div>
                                
				<!-- 底部 -->
                                <nav class="bar bar-tab">
        <a class="external tab-item active" href="/">
                <span class="icon icon-home"></span>
                <span class="tab-label">首页</span>
        </a>
        <a class="tab-item" href="#" onclick="return alert('暂无此功能')">
                <span class="icon icon-friends"></span>
                <span class="tab-label">好友</span>
        </a>
        <a class="tab-item" href="<?php echo url('/netdisk/netdisk/share_list'); ?>">
                <span class="icon icon-share"></span>
                <span class="tab-label">分享</span>
        </a>
        <a class="tab-item open-panel">
                <span class="icon icon-me"></span>
                <span class="tab-label">我的</span>
        </a>
</nav>
                                <!-- 底部 -->
                                
				<!-- 这里是页面内容区 -->
				<div class="content native-scroll">
					<div class="list-block media-list" style="margin: 0;">
						<ul>
                                                    <!--文件夹的数据-->
                                                    <?php if(is_array($fileData['folder']) || $fileData['folder'] instanceof \think\Collection || $fileData['folder'] instanceof \think\Paginator): $i = 0; $__LIST__ = $fileData['folder'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$folder): $mod = ($i % 2 );++$i;?>
							<li>
								<div class="item-content">
									<div class="item-media"><img src="/public/static/icon/folder.png" width="44"></div>
									<div class="item-inner">
										<div class="item-title-row">
											<div class="item-title"><a href="<?php echo url('/netdisk/netdisk/index/folder_id/'.$folder['Id']); ?>" class="external"><?php echo $folder['Folder']; ?></a></div>
											<div class="item-after">
												<a onclick="editFolder('<?php echo $folder['Folder']; ?>',<?php echo $folder['Id']; ?>)"><i class="fa fa-pencil-alt"></i></a>
												<a href="<?php echo url('/netdisk/netdisk/folder_delete/folder_id/'.$folder['Id']); ?>" class="external red"><i class="fa fa-trash-alt"></i></a>
											</div>
										</div>
									</div>
								</div>
							</li>
                                                        <?php endforeach; endif; else: echo "" ;endif; if((!$fileData['folder']) and (!$fileData['file'])): ?><li><div class='item-content'>当前暂无数据，要不咱们上传个试试！</div></li><?php endif; if(is_array($fileData['file']) || $fileData['file'] instanceof \think\Collection || $fileData['file'] instanceof \think\Paginator): $i = 0; $__LIST__ = $fileData['file'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$file): $mod = ($i % 2 );++$i;?>                                            
							<li>
								<div class="item-content">
									<div class="item-media"><img src="/public/static/icon/<?php echo $file['File_ext']; ?>.png" height="44"></div>
									<div class="item-inner">
										<div class="item-title-row">
											<div class="item-title disable-router"><a href="/uploads/<?php echo $file['File_save_name']; ?>" download="<?php echo $file['File_name']; ?>"><?php echo $file['File_name']; ?></a></div>
											<div class="item-after">
												<a href="<?php echo url('/netdisk/netdisk/share/file_id/'.$file['Id']); ?>" class="external"><i class="fa fa-share-alt"></i></a><!--文件分享-->
												<a href="/uploads/<?php echo $file['File_save_name']; ?>" class="external" download="<?php echo $file['File_name']; ?>"><i class="fa fa-download"></i></a>
                                                                                                <a onclick="return confirm('你确定要删除<?php echo $file['File_name']; ?>文件？')" href="<?php echo url('/netdisk/netdisk/file_delete/file_id/'.$file['Id']); ?>" class="external red " ><i class="fa fa-trash-alt"></i></a>
											</div>

										</div>
                                                                            <div class="item-subtitle">
                                                                                <div class="row">
                                                                                    <div class="col-25"><?php echo $file['File_size']; ?></div>
                                                                                    <div class="col-75"><?php echo $file['Upload_time']; ?></div>
                                                                                </div>
                                                                            </div>
									</div>

								</div>
							</li>
                                                        <?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
					</div>
				</div>
			</div>

			<!-- popup, panel 等放在这里 -->
			<div class="panel-overlay"></div>
			<div class="popup popup-add-folder">
				<div class="content-block">
					<h1>添加文件夹</h1>
				</div>

				<form 
                                      action="<?php echo url('/netdisk/netdisk/folder_create/folder_id/'.$folder_id); ?>"           
                                      method="post">
					<div class="list-block">
						<ul>
							<!-- Text inputs -->
							<li>
								<div class="item-content">
									<div class="item-media"><i class="fa fa-folder fa-lg"></i></div>
									<div class="item-inner">
										<div class="item-input">
                                                                                    <input type="text" placeholder="请输入文件夹名" name="folder_name" required>
										</div>
									</div>
								</div>
							</li>

						</ul>
					</div>
					<div class="content-block">
						<div class="row">
							<div class="col-50"><input type="submit" class="button button-big button-fill button-success" value="添加"></div>
							<div class="col-50"><input type="button" class="button button-big button-fill button-danger close-popup" value="关闭"></div>
						</div>
					</div>
				</form>
			</div>

			<div class="popup popup-edit-folder">
				<div class="content-block">
					<h1>编辑文件夹</h1>
				</div>

				<form 
                                      action="<?php echo url('/netdisk/netdisk/folder_create/folder_id/'.$folder_id); ?>"           
                                      method="post">
					<div class="list-block">
						<ul>
							<!-- Text inputs -->
							<li>
								<div class="item-content">
									<div class="item-media"><i class="fa fa-folder fa-lg"></i></div>
									<div class="item-inner">
										<div class="item-input">
                                                                                    <input type="text" placeholder="请输入文件夹名" name="new_folder_name" required>
                                                                                    <input type="hidden" name="folder_Id" />
										</div>
									</div>
								</div>
							</li>

						</ul>
					</div>
					<div class="content-block">
						<div class="row">
							<div class="col-50"><input type="submit" class="button button-big button-fill button-success" value="添加"></div>
							<div class="col-50"><input type="button" class="button button-big button-fill button-danger close-popup" value="关闭"></div>
						</div>
					</div>
				</form>
			</div>                        
			<div class="popup popup-about">
				<header class="bar bar-nav">
					<a class="button button-link button-nav pull-right close-popup">
						关闭
					</a>
					<h1 class="title">关于蓝天</h1>
				</header>
				<div class="content native-scroll">
					<div class="content-inner">
						<div class="content-block">
                                                        <p>蓝天网盘是一款绿色，无广告的网盘，提倡自由分享！</p>
							<p>蓝天网盘同时也为您提供文件的网络备份、同步和分享服务。</p>
							<p>空间大、速度快、安全稳固，支持教育网加速，支持手机端。现在注册即有机会享受15G的免费存储空间</p>
							<p><a class="button close-popup">确定</a></p>
						</div>
					</div>
				</div>
			</div>


			<div class="panel panel-left panel-reveal">
				<div class="content-block">
					<p>用户名：<?php echo $userInfo[0]['Username']; ?></p>
					<p>性别：<?php echo $userInfo[0]['Sex']=='male'?'男':'女'; ?></p>
					<p>专业：<?php echo $userInfo[0]['Major']; ?></p>
					<p><a href="<?php echo url('netdisk/user_quit'); ?>" class="external">退出</a>&nbsp;&nbsp;&nbsp;<a href="#" class="close-panel">关闭</a></p>
				</div>
			</div>

		</div>
		<script type='text/javascript' src="/public/static/sui/js/zepto.js"></script>
		<script type='text/javascript' src="/public/static/sui/js/sm.min.js"></script>
		<script type='text/javascript' src="/public/static/sui/js/sm-extend.min.js"></script>
		<script>
			$.init();
                       
  $(document).on('click', '.confirm-ok-cancel',function () {

      $.confirm('你确定要删除文件吗?',
      
        function () {
            $('.preloader-indicator-overlay').prop('outerHTML','')
            $('.preloader-indicator-modal').prop('outerHTML','');            
             return true;
        },
        function () {
            $('.preloader-indicator-overlay').prop('outerHTML','')
            $('.preloader-indicator-modal').prop('outerHTML','');   
             return false;
        }
      );
  });      
  function editFolder(folderName,folderId){
      console.log(folderName,folderId);
 
      $('.popup-edit-folder form .item-content input')[0].value=folderName;
      $('.popup-edit-folder form .item-content input')[1].value=folderId;
      $('.popup-edit-folder form').attr('action','/netdisk/netdisk/edit_folder/folder_id/'+folderId);
      $.popup('.popup-edit-folder');
  }
		</script>
	</body>
</html>
