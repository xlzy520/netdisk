<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"D:\phpStudy\WWW\www.wangpan.com\public/../application/user\view\user\login.html";i:1561644617;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
        <link rel="stylesheet" href="/public/static/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="/public/static/fontawesome-free-5.8.2-web/css/all.css" />
        <title>登录页面</title>
    </head>
    <body style="background-color: #f5f5f5;">
        <div class="container">	
            <div class="form-box">
                <div class="card bg-light mb-3" style="max-width: 25rem;margin: 12rem auto;">
                    <div class="card-header">
                        <ul class="nav nav-pills justify-content-center">
                            <li class="nav-item">
                                <a class="nav-link active">登陆</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo url('user/register'); ?>">注册</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo url('user/login_check'); ?>">
                            <div class="input-group mb-3 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-user-circle"></i>
                                    </div>
                                </div>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="username"
                                    placeholder="请输入用户名"
                                    required
                                    >
                            </div>
                            <div class="input-group mb-3 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-lock"></i>
                                    </div>
                                </div>
                                <input
                                    type="password"
                                    class="form-control"
                                    placeholder="请输入密码"
                                    name="password"
                                    required
                                    >
                            </div>

                            <div class="input-group mb-3 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-lock"></i>
                                    </div>
                                </div>
                                <input
                                    type="text"
                                    class="form-control"
                                    placeholder="请输入验证码"
                                    name="captcha"
                                    required
                                    >
                                <div class="input-group-prepend">
                                    <img src="<?php echo captcha_src(); ?>" width="160" height="38" style="border: 1px solid #ced4da;border-left: 0;" onclick="this.src='<?php echo captcha_src(); ?>?'+Math.random()"/>
                                </div>			
                            </div>

                            <button type="submit" class="btn btn-info btn-block">登陆</button>
                        </form>
                    </div>
                </div>
          </div>
        </div>			  
    </body>
</html>
